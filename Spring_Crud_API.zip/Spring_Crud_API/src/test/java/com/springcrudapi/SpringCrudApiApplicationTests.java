package com.springcrudapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCrudApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
