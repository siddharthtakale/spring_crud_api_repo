package com.springcrudapi.controller;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springcrudapi.entity.*;
import com.springcrudapi.repository.*;

@RestController
@RequestMapping("/api")
public class EmployeeController {

	@Autowired
	EmployeeRepository employeeRepository;
	
	@PostMapping("/employees")
	public String addemployee(@RequestBody Employee employee) {
		employeeRepository.save(employee);
		return "Employee added Successfully";
	}
	
	@GetMapping("/employees")
	public ResponseEntity<List<Employee>> getallemployee(){
		List<Employee> emplist= new ArrayList<>();
		employeeRepository.findAll().forEach(emplist::add);
		return new ResponseEntity<List<Employee>>(emplist, HttpStatus.OK);
	}
	
	@GetMapping("/employee/{empid}")
	public ResponseEntity<Employee> getEmpById(@PathVariable long empid){
		Optional<Employee> opemp= employeeRepository.findById(empid);
		if(opemp.isPresent()) {
			return new ResponseEntity<Employee>(opemp.get(), HttpStatus.FOUND);
		}else {
			return new ResponseEntity<Employee>(HttpStatus.NOT_FOUND);
		}
	}
	@PutMapping("/employee/{empid}")
	public String updateEmpById(@PathVariable long empid, @RequestBody Employee employee) {
		Optional<Employee> emp=employeeRepository.findById(empid);
		if(emp.isPresent()) {
			Employee empexist=emp.get();
			empexist.setEmpname(employee.getEmpname());
			empexist.setEmpsalary(employee.getEmpsalary());
			empexist.setEmpage(employee.getEmpage());
			empexist.setEmp_city(employee.getEmpcity());
			employeeRepository.save(empexist);
			
			return "Employee Details against id "+empid+"updated";
		}else {
			return "Employee id "+empid+"does not exists";
		}
	}
	@DeleteMapping("/employee/{empid}")
	public String deleteEmpId(@PathVariable long empid) {
		employeeRepository.deleteById(empid);
		return "Employee id "+empid+" deleted";
	}
	
	@DeleteMapping("/employees")
	public String deleteAllEmp() {
		employeeRepository.deleteAll();
		return "All Employee deleted successfully";
	}
		
}
