package com.springcrudapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCrudApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCrudApiApplication.class, args);
	}

}
